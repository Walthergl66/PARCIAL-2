
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { Builder } = require('xml2js');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Función para guardar datos en XML
function saveToXML(articles) {
    const builder = new Builder();
    const xml = builder.buildObject({ articles: { article: articles } }); // Construir el XML con un array de artículos
    fs.writeFileSync('articles.xml', xml);
}

app.post('/submit-article', (req, res) => {
    const newArticle = req.body;

    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);

        const newId = articles.length > 0 ? articles[articles.length - 1].id + 1 : 1;
        newArticle.id = newId;
        newArticle.status = 'pendiente';

        articles.push(newArticle);

        // Guardar en JSON
        fs.writeFile('articles.json', JSON.stringify(articles, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error al guardar el artículo' });
            }

            // Guardar en XML
            saveToXML(articles);

            res.json({ success: true, message: 'Artículo enviado correctamente' });
        });
    });
});

app.get('/get-articles', (req, res) => {
    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const pendingArticles = articles.filter(article => article.status === 'pendiente');
        res.json(pendingArticles);
    });
});

app.post('/approve-article/:id', (req, res) => {
    const articleId = req.params.id;

    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const article = articles.find(a => a.id === parseInt(articleId));

        if (!article) {
            return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
        }

        article.status = 'aprobado';

        fs.writeFile('articles.json', JSON.stringify(articles, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error al guardar el artículo' });
            }

            // Guardar en XML
            saveToXML(articles);

            res.json({ success: true });
        });
    });
});

app.post('/reject-article/:id', (req, res) => {
    const articleId = req.params.id;

    fs.readFile('articles.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error al leer los artículos' });
        }

        const articles = JSON.parse(data);
        const article = articles.find(a => a.id === parseInt(articleId));

        if (!article) {
            return res.status(404).json({ success: false, message: 'Artículo no encontrado' });
        }

        article.status = 'rechazado';

        fs.writeFile('articles.json', JSON.stringify(articles, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error al guardar el artículo' });
            }

            // Guardar en XML
            saveToXML(articles);

            res.json({ success: true });
        });
    });
});

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
